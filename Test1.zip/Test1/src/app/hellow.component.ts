import { Component, Input } from '@angular/core';

@Component({
  selector: 'ria-hello',
  template: '<p>Hello, {{name}}!</p>',
})
export class HellowComponent {
  @Input() name: string;
}