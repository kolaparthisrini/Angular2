import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
})
export class AppComponent {
  title :string= 'Capgs...';

  clicked(event) {
    alert("Sorry Wrong Button pressed");
  }

  appList: any[] = [ {
    "ID": "1"
      },

    {
      "ID": "2",

    } ];
}
