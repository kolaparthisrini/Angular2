# angular-2-router

Routing and navigation with Angular 2 and TypeScript.

Used by [lishman.io](http://lishman.io)
