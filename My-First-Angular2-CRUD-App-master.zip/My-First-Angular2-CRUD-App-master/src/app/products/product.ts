export class Product {
    id: number;
    productName: string;
    productCode: string;
    releaseDate: string;
    description: string;
    price: number;
    constructor(id: number, productName: string, productCode: string, releaseDate: string, description: string, price: number) { }
}